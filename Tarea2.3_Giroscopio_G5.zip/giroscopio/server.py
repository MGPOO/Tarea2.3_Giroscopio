import asyncio
import websockets
import os
import socket

def get_local_ip():
    """Obtiene la IP local automáticamente."""
    try:
        # Crear un socket temporal para detectar la IP local
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            # Conectar a una dirección remota ficticia para obtener la IP local
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
    except Exception as e:
        print(f"Error al obtener la IP local: {e}")
        return "127.0.0.1"  # IP de loopback como respaldo

async def handler(websocket):
    """Maneja la comunicación con un cliente."""
    print("Cliente conectado")
    try:
        async for message in websocket:
            print(f"Comando recibido: {message}")

            if message == "abrir navegador":
                os.system("start https://www.google.com")
            elif message == "abrir Word":
                os.system("start winword")
            elif message == "reproducir multimedia":
                os.system("start wmplayer")
            else:
                print("Comando no reconocido")
    except websockets.exceptions.ConnectionClosed as e:
        print(f"Cliente desconectado")
    finally:
        print("Esperando nuevas conexiones...")

async def main():
    """Inicia el servidor WebSocket."""
    ip_address = get_local_ip()
    print(f"Iniciando servidor WebSocket en ws://{ip_address}:8765")
    async with websockets.serve(handler, ip_address, 8765):
        await asyncio.Future()  # Mantener el servidor en ejecución

if __name__ == "__main__":
    asyncio.run(main())
